//user schema for login
export class User{
    constructor(
        public username:number,
        public password:string
    ){}
}